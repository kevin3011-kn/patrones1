package co.edu.udistrital.model;

public interface EnchufeEuropeo {
	 void conectar220V();
}
