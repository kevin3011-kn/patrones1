package co.edu.udistrital.model;

public class EnchufeAmericano {
	 public void conectar110V() {
	        System.out.println("Conectado a 110V");
	    }
}
