package co.edu.udistrital.view;

public class VistaEnchufe {
	 public void mostrarConexion() {
	        System.out.println("Intentando conectar enchufe europeo...");
	    }

}
