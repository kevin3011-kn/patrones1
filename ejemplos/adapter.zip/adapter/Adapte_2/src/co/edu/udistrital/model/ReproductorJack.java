package co.edu.udistrital.model;

public class ReproductorJack {
    public void conectarJack() {
        System.out.println("Audio conectado por Jack");
    }
}
