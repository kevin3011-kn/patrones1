package co.edu.udistrital.model;

public interface ReproductorBluetooth {

	void conectarBluetooth();
}
