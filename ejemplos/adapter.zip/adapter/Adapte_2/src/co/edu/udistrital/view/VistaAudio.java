package co.edu.udistrital.view;

public class VistaAudio {
    public void mostrarConexion() {
        System.out.println("Reproduciendo audio...");
    }
}
