package co.edu.udistrital.model;

public class DocumentoWord {
    public void abrirDoc() {
        System.out.println("Abriendo documento Word...");
    }
}
