package co.edu.udistrital.model;

public interface DocumentoPDF {
	void abrirPDF();
}
