package co.edu.udistrital.view;

public class VistaDocumento {
    public void mostrar() {
        System.out.println("Abriendo documento...");
    }
}
