package co.edu.udistrital.controller;

public class Main {
	public static void main(String[] args) {
        ComputerController controller = new ComputerController();

        controller.construirComputadora("oficina");
        controller.construirComputadora("gaming");
    }

}
