package co.edu.udistrital.model.abstracto;

public interface RelojFactory {
	
    Reloj crearReloj();
}