package co.edu.udistrital.model.abstracto;

public interface MusicFactory {
    Music createMusic();
}
