package co.edu.udistrital.model.abstracto;

public interface NumeroFactory {
    
    Numero crearNumero(int numero);
    
}
