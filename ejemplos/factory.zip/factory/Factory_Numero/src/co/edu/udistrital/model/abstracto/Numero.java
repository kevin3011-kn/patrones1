package co.edu.udistrital.model.abstracto;

public abstract class Numero {

	protected int numero;
	

	public Numero(int numero) {
		this.numero = numero;
		
	}

	public abstract String describir();

	

}
