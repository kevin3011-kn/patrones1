package co.edu.udistrital.model.abstracto;

public interface SalarioFactory {
    
    Salario crearSalario(int salario);
    
}
