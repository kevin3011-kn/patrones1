package co.edu.udistrital.model.abstracto;

public abstract class Angulo {

	protected int angulo;
	

	public Angulo(int anguloA) {
		
		this.angulo = anguloA;
	
	}

	public abstract String describir();



}
