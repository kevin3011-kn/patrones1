package view;

public class VistaMensaje {
    public void mostrar(String texto) {
        System.out.println("Mensaje decorado: " + texto);
    }
}