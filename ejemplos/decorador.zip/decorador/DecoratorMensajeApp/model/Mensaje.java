package model;

public interface Mensaje {
    String obtenerTexto();
}