package model;

public class MensajeBasico implements Mensaje {
    public String obtenerTexto() {
        return "Hola mundo";
    }
}