package view;

public class VistaForma {
    public void mostrar() {
        System.out.println("Mostrando forma...");
    }
}
