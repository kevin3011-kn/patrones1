package model;

public class Rojo implements Color {
    public String usarColor() {
        return "rojo";
    }
}
