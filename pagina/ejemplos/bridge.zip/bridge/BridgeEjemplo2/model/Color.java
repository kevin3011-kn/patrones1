package model;

public interface Color {
    String usarColor();
}
