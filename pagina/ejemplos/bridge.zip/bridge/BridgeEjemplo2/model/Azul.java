package model;

public class Azul implements Color {
    public String usarColor() {
        return "azul";
    }
}
