package co.edu.udistrital.view;

public class VistaControl {
    public void mostrar() {
        System.out.println("Usando control remoto...");
    }
}