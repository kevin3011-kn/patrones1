package co.edu.udistrital.model;

public class TV implements Dispositivo {
    public void encender() {
        System.out.println("TV encendida");
    }

    public void apagar() {
        System.out.println("TV apagada");
    }
}

