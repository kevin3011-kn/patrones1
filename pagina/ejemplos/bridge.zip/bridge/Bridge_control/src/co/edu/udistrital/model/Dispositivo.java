package co.edu.udistrital.model;

public interface Dispositivo {
    void encender();
    void apagar();
}
