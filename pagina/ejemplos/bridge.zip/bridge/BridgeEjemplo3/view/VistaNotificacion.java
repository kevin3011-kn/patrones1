package view;

public class VistaNotificacion {
    public void mostrar(String tipo) {
        System.out.println("Enviando notificación: " + tipo);
    }
}
