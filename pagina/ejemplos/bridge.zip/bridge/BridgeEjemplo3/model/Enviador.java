package model;

public interface Enviador {
    void enviar(String mensaje);
}
