package model;

public interface ArchivoComponente {
    void mostrar();
}