package view;

public class VistaExplorador {
    public void mostrarInicio() {
        System.out.println("Explorador de archivos:");
    }
}