package model;

public interface MenuComponente {
    void mostrar();
}