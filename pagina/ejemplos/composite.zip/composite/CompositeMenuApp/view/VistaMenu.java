package view;

public class VistaMenu {
    public void mostrarInicio() {
        System.out.println("Estructura del menú:");
    }
}