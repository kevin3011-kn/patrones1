package model;

public interface ComponenteEmpleado {
    void mostrarDetalles();
}
