package view;

public class VistaOrganizacion {
    public void mostrar() {
        System.out.println("Mostrando jerarquía de empleados:");
    }
}
