package co.edu.udistrital.controller;

public class AplMain {

	public static void main(String[] args) {

		UsuarioController control;
		control = new UsuarioController();
		control.run();

	}

}
