package co.edu.udistrital.controller;

public class AplMain {

	public static void main(String[] args) {

		VehiculoController control;
		control = new VehiculoController();
		control.run();

	}

}
